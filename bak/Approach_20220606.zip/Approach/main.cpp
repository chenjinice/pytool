#include <EwayFunc/FuncSdkLib.h>
#include "Approach.h"

int main()
{
   ewayos::FunctionRun("127.0.0.1","Approach");
   return 0;
}