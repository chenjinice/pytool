#include "ForkliftApp.h"
#include <EwayFunc/FuncSdkLib.h>
#include <EwayMath/BasicMath.h>

Declare_FunSdk_Lib(ForkliftApp)
Declare_Function_ID("e9e902b7-42fd-4085-9787-f35a16661236")
Declare_Function_Priority(FunPri_Normal)

RegisterMessage_Start
RegisterMessage_End

BEGIN_FIFEMSG_MAP(ForkliftApp,CFuncInterface)
//MSG_FIFMAP(FunMsg_User+1,OnMessageProcess)
END_FIFMSG_MAP

#define Stage_Idle          0
#define Stage_Uninit        1
#define Stage_Init          2
#define Stage_Init2         27
#define Stage_TakingS       3
#define Stage_GraspS        4
#define Stage_LiftS         5
#define Stage_BackToOrig    6
#define Stage_LiftSUp       7
#define Stage_ApprocahB     8
#define Stage_Pile          9
#define Stage_LooseS        10
#define Stage_BackToTake    11
#define Stage_ClampDown     12
#define Stage_TakePile      13
#define Stage_GraspB        14
#define Stage_LiftB         15
#define Stage_Navigation    16
#define Stage_PutDownB      17
#define Stage_LooseB        18
#define Stage_ClampUp       19
#define Stage_GraspS2       20
#define Stage_LiftS2        21
#define Stage_BackToPut     22
#define Stage_ForwardToPut  23
#define Stage_PutS2         24
#define Stage_LooseS2       25
#define Stage_BackToFinish  26


#define DriveMode_Idel      1
#define DriveMode_Drive     2
#define DriveMode_Reverse   3
#define DriveMode_Null      4

#define First

ForkliftApp::ForkliftApp()
{
    m_uCurStage = Stage_Idle;
    EClearGuid(&m_gVisualServoID);
}

ForkliftApp::~ForkliftApp()
{
}

eint ForkliftApp::Initialize(std::vector<eint> &vFeatureList,ebool &bLimbAuthority,edouble &dTimeOut)
{
    vFeatureList.push_back(Message_Code_PaperRollDect);
    vFeatureList.push_back(Message_Code_Slam_Localization);
    //vFeatureList.push_back(Message_Code_DriveMode);
    //vFeatureList.push_back(10077);
    //vFeatureList.push_back(Message_Code_FolkliftClampState);


    bLimbAuthority = true;
    dTimeOut = 3;

    m_fWheelSpeed = 3;

    m_fClampOpenParam = 0;
    m_fClampCloseParam = 0.24;
    m_fLiftUpParam = 0.6;
    m_fLitDownParam = 0.1;

    m_fLiftHighParam = 2.02;
    m_fLitPileParam = 1.8;


    return ERR_NONE;
}

eint ForkliftApp::Destroy()
{
    return ERR_NONE;
}

eint ForkliftApp::CheckMsgCode(eint nMsgCode)
{
    if(Message_Code_PaperRollDect==nMsgCode)
        return MsgProcCode_Notify;
    else
        return MsgProcCode_Record;
}

//#include "/home/muniu/svn/EwayOS/RoboticSys/EwayOS/Function/Navigation/NavigationUltility.h"
void ForkliftApp::JobStart()
{
    ewayos::Log::inf("ForkliftApp","Job Start!");
    eint nRetCode = 0;
    euint unCmdSN = 0;

    EClearGuid(&m_gVisualServoID);
    EClearGuid(&m_gNavigationID);

//    CCmdDoneMessage iCmdDoneMsg;
//    iCmdDoneMsg.m_nCmdID = Command_Code_ClampLift;
//    iCmdDoneMsg.m_dTimeStamp = ewayos::Time::GetCurrentTime();
//    iCmdDoneMsg.m_nCmdSN = 1;
//    iCmdDoneMsg.m_nCmdStatus = ERR_NONE;

//    m_uCurStage = Stage_ApprocahB;

//    nRetCode = BaseSetDriveMode(DriveMode_Drive, unCmdSN);

//    //ProcMotCmdDone(iCmdDoneMsg.m_dTimeStamp, &iCmdDoneMsg);
//    SetTimer(1000);
//    return;

    m_unInitStatus = 0;
    m_uCurStage = Stage_Uninit;//command done not ready, no wait 3s change to Init stage

    nRetCode = BaseSetDriveMode(DriveMode_Drive, unCmdSN);
    if(ERR_NONE!=nRetCode)
    {
        ewayos::Log::err("ForkliftApp","SetDriveMode failed, %d",nRetCode);
        return;
    }
    EASSERT(ERR_NONE==nRetCode);

    nRetCode = BaseStop(0,unCmdSN);
    if(ERR_NONE!=nRetCode)
    {
        ewayos::Log::err("ForkliftApp","BaseStop failed, %d",nRetCode);
        return;
    }

    nRetCode = ClampOpen(m_fClampOpenParam,1,unCmdSN);
    if(ERR_NONE!=nRetCode)
    {
        ewayos::Log::err("ForkliftApp","ClampMove failed, %d",nRetCode);
        return;
    }
    nRetCode = ClampLift(m_fLitDownParam,1,unCmdSN);
    if(ERR_NONE!=nRetCode)
    {
        ewayos::Log::err("ForkliftApp","ClampMove failed, %d",nRetCode);
        return;
    }
    SetTimer(1000);
    return ;
}

eint ForkliftApp::ProcLocalizationMsg(edouble dTimeStamp, CLocalizationMsg* piMsg)
{
    return ERR_NONE;
}
eint ForkliftApp::ProcPaperRollMsg(edouble dTimeStamp, CPaperRollMsg* piMsg)
{
    eint nRetCode = 0;
    std::string strParam;
    std::vector<CFunParamVal> vParamList;
    vParamList.resize(3);
    vParamList[0].m_strParamName = "ObserveTargetRadius";
    vParamList[1].m_strParamName = "AppoarchTargetRadius";
    vParamList[2].m_strParamName = "Payload";
    if(Stage_Init==m_uCurStage||Stage_ApprocahB==m_uCurStage||Stage_TakePile==m_uCurStage)
    {
        if(Stage_Init==m_uCurStage)
        {
            vParamList[0].m_strParamValue = "0.5";
            vParamList[1].m_strParamValue = "0.5";
            vParamList[2].m_strParamValue = "0";
        }
        else if(Stage_ApprocahB==m_uCurStage)
        {
            vParamList[0].m_strParamValue = "0.6";
            vParamList[1].m_strParamValue = "0.5";
            vParamList[2].m_strParamValue = "600";
        }
        else if(Stage_TakePile==m_uCurStage){

            vParamList[0].m_strParamValue = "0.6";
            vParamList[1].m_strParamValue = "0.6";
            vParamList[2].m_strParamValue = "0";
        }

        SetParamStr(vParamList,strParam);
        if(ECheckGuidEmpty(&m_gVisualServoID))
        {
            nRetCode = AddChildFun(m_szVisualServoFuncName,&m_gVisualServoID,strParam);
            if(ERR_NONE==nRetCode)
            {
                if(Stage_Init==m_uCurStage)
                {
                    m_uCurStage = Stage_TakingS;
                }
                ewayos::Log::inf("ForkliftApp","AddChildFun %s OK!",m_szVisualServoFuncName);
            }
            else
            {
                ewayos::Log::err("ForkliftApp","AddChildFun %s failed code %d!",m_szVisualServoFuncName,nRetCode);
            }
        }
    }
    return ERR_NONE;
}
#include "/home/muniu/svn/Dev2004/RoboticSys/EwayOS/Function/Navigation/NavigationUltility.h"
//#include "/home/guqy/svn/Dev2004/RoboticSys/EwayOS/Function/Navigation/NavigationUltility.h"
eint ForkliftApp::Navigation()
{
    eint nRetCode = 0;
    std::string strParam;
    CPose2D iTarget;

#ifdef First
    iTarget.m_dx = 8;
    iTarget.m_dy = 3;
    iTarget.m_dRz = 0;
#else
    iTarget.m_dx = 3;
    iTarget.m_dy = 5.5;
    iTarget.m_dRz = 3.14;
#endif
    EGUID gMapID;
    EStringToGuid(&gMapID,"cf2450be-fc5d-4b21-9c69-67a7c52e8f99");
    CNaviUltility::GetParamStr(iTarget,&gMapID,strParam);

    if(ECheckGuidEmpty(&m_gNavigationID))
    {
        nRetCode = AddChildFun(m_szNavigationFuncName,&m_gNavigationID,strParam);
        if(ERR_NONE==nRetCode)
        {
            m_uCurStage = Stage_Navigation;
            ewayos::Log::inf("ForkliftApp","AddChildFun %s OK!",m_szNavigationFuncName);
        }
        else
        {
            ewayos::Log::err("ForkliftApp","AddChildFun %s failed code %d!",m_szNavigationFuncName,nRetCode);
        }
    }
    return nRetCode;
}
eint ForkliftApp::BeginToTake()
{
    eint nRetCode=0;
    euint unCmdSN=0;

    nRetCode = ClampOpen(m_fClampCloseParam,1,unCmdSN);
    if(ERR_NONE==nRetCode)
    {
        ewayos::Log::inf("ForkliftApp","Clamp Closing!");
        m_uCurStage = Stage_GraspS;
    }
    else
    {
        ewayos::Log::err("ForkliftApp","Clamp Closing failed code %d!",nRetCode);
    }

    return nRetCode;
}

eint ForkliftApp::ProcChildFunQuit(edouble dTimeStamp,EGUID* pgFunID,eint nRetCode,std::string& iRetStr)
{
    euint unCmdSN=0;

    BaseSetDriveMode(DriveMode_Drive,unCmdSN);
    if(0==ECompareGuid(pgFunID,&m_gVisualServoID))
    {
        ewayos::Log::inf("ForkliftApp","%s quit!",m_szVisualServoFuncName);
        EClearGuid(&m_gVisualServoID);
        if(m_uCurStage==Stage_TakingS)
        {
            nRetCode = ClampOpen(m_fClampCloseParam,1,unCmdSN);
            if(ERR_NONE==nRetCode)
            {
                ewayos::Log::inf("ForkliftApp","Clamp Closing!");
                m_uCurStage = Stage_GraspS;
            }
            else
            {
                ewayos::Log::err("ForkliftApp","Clamp Closing failed code %d!",nRetCode);
            }
        }
        else if(m_uCurStage==Stage_ApprocahB)
        {
            nRetCode = ClampLift(m_fLitPileParam,1,unCmdSN);
            if(ERR_NONE!=nRetCode){
                ewayos::Log::err("ForkliftApp","pile paper error, code %d",nRetCode);
            }
            else
            {
                m_uCurStage = Stage_Pile;
            }
        }
        else if(m_uCurStage==Stage_TakePile)
        {
            nRetCode = ClampOpen(m_fClampCloseParam,1,unCmdSN);
            if(ERR_NONE!=nRetCode){
                ewayos::Log::err("ForkliftApp","clamp close to take pile paper error, code %d",nRetCode);
            }
            else
            {
                m_uCurStage = Stage_GraspB;
            }
        }
        return ERR_NONE;
    }
    if(0==ECompareGuid(pgFunID,&m_gNavigationID))
    {
        ewayos::Log::inf("ForkliftApp","%s quit!",m_szNavigationFuncName);
        EClearGuid(&m_gNavigationID);
        if(m_uCurStage!=Stage_Navigation)
            return ERR_NONE;

        nRetCode = ClampLift(m_fLitDownParam,1,unCmdSN);
        if(ERR_NONE!=nRetCode)
        {
            ewayos::Log::err("ForkliftApp","ClampMove failed, %d",nRetCode);
            return nRetCode;
        }

        m_uCurStage = Stage_PutDownB;
    }
    return ERR_NONE;
}

void ForkliftApp::JobFailed(eint nErrCode)
{
    ewayos::Log::err("ForkliftApp","Job failed, code %d!",nErrCode);
    return ;
}

eint ForkliftApp::ProcTimer(edouble dTimeStamp)
{
    eint nRetCode = 0;
    euint unCmdSN=0;

    if(m_nWaitCount>=0)
        m_nWaitCount--;

    CLocalizationMsg iLocalization;
    GetMsgData(&iLocalization);

    ewayos::Log::inf("ForkliftApp","timer %d stage %d, %f %f %f",
                     m_nWaitCount,m_uCurStage,
                     iLocalization.m_iCurrentPose.m_iPosition.m_dx,
                     iLocalization.m_iCurrentPose.m_iPosition.m_dy,
                     iLocalization.m_iCurrentPose.m_iRotation.m_dRz);

    switch(m_uCurStage)
    {
    case Stage_Idle:
        break;
    case Stage_Init:
        ewayos::Log::inf("ForkliftApp","wait for paper roll detect");
        break;
    default:
        break;
    }
    return ERR_NONE;
}

eint ForkliftApp::ProcChildNotify(EGUID* pChildID, CSetParamMsg* piMsg)
{
//    eint32 nRetCode = 0;
//    std::string strParamName;
//    if(0==ECompareGuid(pChildID,&m_gVisualServoID))
//    {
//        strParamName = "RetCode";
//        GetParamIntVal(piMsg->m_strPara,strParamName,nRetCode);
//        ewayos::Log::inf("ForkliftApp","%s ChildNotify finished code %d!",m_szVisualServoFuncName,nRetCode);
//        if(m_uCurStage!=Stage_Taking)
//            return ERR_NONE;
//        BeginToTake();
//    }

    return ERR_NONE;
}

eint ForkliftApp::ProcFeatureStatus(edouble dTimeStamp, CFeatureMessage* piFeaStatus)
{
    return ERR_NONE;
}

eint ForkliftApp::ProcMotCmdDone(edouble dTimeStamp, CCmdDoneMessage* piCmdDone)
{
    euint unCmdSN=0;
    eint32 nRetCode = 0;

    ewayos::Log::inf("ForkliftApp","Get CmdDone %d %d %d %d",piCmdDone->m_nCmdID,piCmdDone->m_nCmdSN,piCmdDone->m_nCmdStatus,m_unInitStatus);
    switch(m_uCurStage)
    {
    case Stage_Uninit:
        if(Command_Code_ClampLift == piCmdDone->m_nCmdID)
        {
            m_unInitStatus = (m_unInitStatus|InitStatusMask_Lift);
            if(ERR_NONE!=piCmdDone->m_nCmdStatus)
            {
                ewayos::Log::inf("ForkliftApp","FolkMove status failed %d, stage %d!",piCmdDone->m_nCmdStatus,m_uCurStage);
            }
            else
            {
                ewayos::Log::inf("ForkliftApp","FolkMove status ok status, stage %d!",m_unInitStatus,m_uCurStage);
            }
        }
        if(Command_Code_ClampOpen== piCmdDone->m_nCmdID)
        {
            m_unInitStatus = (m_unInitStatus|InitStatusMask_Clamp);
            if(ERR_NONE!=piCmdDone->m_nCmdStatus)
            {
                ewayos::Log::inf("ForkliftApp","ClampMove status failed %d, stage %d!",piCmdDone->m_nCmdStatus,m_uCurStage);
            }
            else
            {
                ewayos::Log::inf("ForkliftApp","ClampMove status ok status, stage %d!",m_unInitStatus,m_uCurStage);
            }
        }
        if(Command_Code_SetDrvMode == piCmdDone->m_nCmdID)
        {
            m_unInitStatus = (m_unInitStatus|InitStatusMask_DrvMode);
            if(ERR_NONE!=piCmdDone->m_nCmdStatus)
            {
                ewayos::Log::inf("ForkliftApp","SetDrvMode status failed %d, stage %d!",piCmdDone->m_nCmdStatus,m_uCurStage);
            }
            else
            {
                ewayos::Log::inf("ForkliftApp","SetDrvMode status ok status, stage %d!",m_unInitStatus,m_uCurStage);
            }
        }
        if(m_unInitStatus>=(InitStatusMask_DrvMode+InitStatusMask_Lift+InitStatusMask_Clamp))
        {
            m_uCurStage = Stage_Init2;//Stage_Init;
            ewayos::Log::inf("ForkliftApp","init1 ok, init2!,stage %d",m_uCurStage);
        }
        break;

    case Stage_Init2:
        if(Command_Code_ClampTilt== piCmdDone->m_nCmdID)
        {
            m_unInitStatus = (m_unInitStatus|InitStatusMask_Tilt);
            if(ERR_NONE!=piCmdDone->m_nCmdStatus)
            {
                ewayos::Log::inf("ForkliftApp","ClampTilt status failed %d, stage %d!",piCmdDone->m_nCmdStatus,m_uCurStage);
            }
            else
            {
                ewayos::Log::inf("ForkliftApp","ClampTilt status ok status, stage %d!",m_unInitStatus,m_uCurStage);
            }
        }
        if(Command_Code_ClampRoll == piCmdDone->m_nCmdID)
        {
            m_unInitStatus = (m_unInitStatus|InitStatusMask_Roll);
            if(ERR_NONE!=piCmdDone->m_nCmdStatus)
            {
                ewayos::Log::inf("ForkliftApp","ClampRoll status failed %d, stage %d!",piCmdDone->m_nCmdStatus,m_uCurStage);
            }
            else
            {
                ewayos::Log::inf("ForkliftApp","ClampRoll status ok status, stage %d!",m_unInitStatus,m_uCurStage);
            }
        }
        if(m_unInitStatus>=(InitStatusMask_DrvMode+InitStatusMask_Lift+InitStatusMask_Clamp))
        {
            m_uCurStage = Stage_Init;
            ewayos::Log::inf("ForkliftApp","init ok, wait for paperroll detect to begin approach&grasp!,stage %d",m_uCurStage);
        }
        break;
    case Stage_GraspS:
        if(Command_Code_ClampOpen != piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","Grasp over!");
        nRetCode = ClampLift(m_fLiftUpParam,1,unCmdSN);
        if(ERR_NONE==nRetCode)
        {
            ewayos::Log::inf("ForkliftApp","ForkMove Up!");
            m_uCurStage = Stage_LiftS;
        }
        else
        {
            ewayos::Log::err("ForkliftApp","ForkMove Up failed code %d!",nRetCode);
        }
        break;
    case Stage_LiftS:
        if(Command_Code_ClampLift != piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","LiftUp over!");
        nRetCode = MoveBack();
        if(ERR_NONE==nRetCode){
            m_uCurStage = Stage_BackToOrig;
        }
        break;
    case Stage_BackToOrig:
        if(Command_Code_BaseTrajWithV != piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","Move back to grasp big one finish!");
        nRetCode = ClampLift(m_fLiftHighParam,1,unCmdSN);
        nRetCode = BaseSetDriveMode(DriveMode_Drive, unCmdSN);

        m_uCurStage = Stage_LiftSUp;
        break;
    case Stage_LiftSUp:
        if(Command_Code_ClampLift != piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","Lift Small one Up finish!");
        m_uCurStage = Stage_ApprocahB;
        break;
    case Stage_Pile:
        if(Command_Code_ClampLift != piCmdDone->m_nCmdID)
            return ERR_NONE;
        m_uCurStage = Stage_Idle;
        ewayos::Log::inf("ForkliftApp","pile paper finish!");
        nRetCode = ClampOpen(m_fClampOpenParam,1,unCmdSN);
        if(ERR_NONE==nRetCode)
        {
            ewayos::Log::inf("ForkliftApp","loose small paper!");
            m_uCurStage = Stage_LooseS;
        }
        else
        {
            ewayos::Log::err("ForkliftApp","ClampMove Open failed code %d!",nRetCode);
        }
        break;
    case Stage_LooseS:
        if(Command_Code_ClampOpen != piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","pile paper loose finish!");
        nRetCode = MoveBack(false);
        if(ERR_NONE==nRetCode)
        {
            ewayos::Log::inf("ForkliftApp","move back to take piled papers");
            m_uCurStage = Stage_BackToTake;//Stage_ClampDown;
        }
        else
        {
            ewayos::Log::err("ForkliftApp","move back to take piled papers failed, %d!",nRetCode);
        }
        break;
    case Stage_BackToTake:
        if(Command_Code_BaseTrajWithV != piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","clamp down to takeB finish!");
        nRetCode = BaseSetDriveMode(DriveMode_Drive, unCmdSN);
        nRetCode = ClampLift(m_fLitDownParam,1,unCmdSN);
        if(ERR_NONE==nRetCode)
        {
            ewayos::Log::inf("ForkliftApp","clamp down to hold two papers");
            m_uCurStage = Stage_ClampDown;
        }
        else
        {
            ewayos::Log::err("ForkliftApp","clamp down to hold two papers failed, %d!",nRetCode);
        }
        break;
    case Stage_ClampDown:
        if(Command_Code_ClampLift != piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","move back to takeB finish!");
        m_uCurStage = Stage_TakePile;
        break;
    case Stage_GraspB:
        if(Command_Code_ClampOpen != piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","ClampMove close to hold two papers over!");
        nRetCode = ClampLift(m_fLiftUpParam,1,unCmdSN);
        if(ERR_NONE!=nRetCode)
        {
            ewayos::Log::err("ForkliftApp","ClampLift to take piled paper failed, code %d!",nRetCode);
        }
        else
        {
            ewayos::Log::inf("ForkliftApp","ClampLift to take piled paper!");
            m_uCurStage = Stage_LiftB;
        }
        break;
    case Stage_LiftB:
        if(Command_Code_ClampLift != piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","LiftUp over!");
        nRetCode = Navigation();
        if(ERR_NONE==nRetCode){
            m_uCurStage = Stage_Navigation;
        }
        break;
    case Stage_PutDownB:
        if(Command_Code_ClampLift != piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","put piled paper over!");
        nRetCode = ClampOpen(m_fClampOpenParam,1,unCmdSN);
        if(ERR_NONE==nRetCode)
        {
            ewayos::Log::inf("ForkliftApp","ClampMove loose piled paper!");
            m_uCurStage = Stage_LooseB;
        }
        else
        {
            ewayos::Log::err("ForkliftApp","ClampMove loose piled paper failed %d!",nRetCode);
        }
        break;
    case Stage_LooseB:
        if(Command_Code_ClampOpen!= piCmdDone->m_nCmdID)
            return ERR_NONE;

        ewayos::Log::inf("ForkliftApp","ClampMove loose piled paper! over!");
        nRetCode = MoveBack();
        if(ERR_NONE==nRetCode){
            m_uCurStage = Stage_BackToFinish;
        }
        break;


        ewayos::Log::inf("ForkliftApp","lose piled paper over!");
        nRetCode = ClampLift(m_fLitPileParam,1,unCmdSN);
        if(ERR_NONE==nRetCode)
        {
            ewayos::Log::inf("ForkliftApp","Clamplift to take small paper!");
            m_uCurStage = Stage_ClampUp;
        }
        else
        {
            ewayos::Log::err("ForkliftApp","Clamplift to take small paper, failed %d!",nRetCode);
        }
        break;
    case Stage_ClampUp:
        if(Command_Code_ClampLift!= piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","lift up to take small paper ok!");
        nRetCode = ClampOpen(m_fClampCloseParam,1,unCmdSN);
        if(ERR_NONE==nRetCode)
        {
            ewayos::Log::inf("ForkliftApp","ClampClose to take small paper!");
            m_uCurStage = Stage_GraspS2;
        }
        else
        {
            ewayos::Log::err("ForkliftApp","ClampClose to take small paper failed %d!",nRetCode);
        }
        break;
    case Stage_GraspS2:
        if(Command_Code_ClampOpen!= piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","ClampClose to take small paper ok!");
        nRetCode = ClampLift(m_fLiftHighParam,1,unCmdSN);
        if(ERR_NONE==nRetCode)
        {
            ewayos::Log::inf("ForkliftApp","ClampLift to move small paper!");
            m_uCurStage = Stage_LiftS2;
        }
        else
        {
            ewayos::Log::err("ForkliftApp","ClampClose to move small paper failed %d!",nRetCode);
        }
        break;
    case Stage_LiftS2:
        if(Command_Code_ClampOpen != piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","ClampLift to move small paper over!");
        nRetCode = MoveBack();
        if(ERR_NONE==nRetCode){
            m_uCurStage = Stage_BackToPut;
        }
        break;
    case Stage_BackToPut:
        if(Command_Code_BaseTrajWithV != piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","Move back to put small one finish!");
        nRetCode = MoveForward();
        if(ERR_NONE==nRetCode){
            m_uCurStage = Stage_ForwardToPut;
        }
        break;
    case Stage_ForwardToPut:
        if(Command_Code_BaseTrajWithV != piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","Move forward to put small one finish!");
        nRetCode = ClampLift(m_fLitDownParam,1,unCmdSN);
        if(ERR_NONE==nRetCode)
        {
            ewayos::Log::inf("ForkliftApp","ClampLift to put small paper!");
            m_uCurStage = Stage_PutS2;
        }
        else
        {
            ewayos::Log::err("ForkliftApp","ClampClose to put small paper failed %d!",nRetCode);
        }
        break;
    case Stage_PutS2:
        if(Command_Code_ClampLift != piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","ClampLift to put small paper finish!");
        nRetCode = ClampOpen(m_fClampOpenParam,1,unCmdSN);
        if(ERR_NONE==nRetCode)
        {
            ewayos::Log::inf("ForkliftApp","ClampOpen to loose small paper!");
            m_uCurStage = Stage_LooseS2;
        }
        else
        {
            ewayos::Log::err("ForkliftApp","ClampOpen to loose small paper failed %d!",nRetCode);
        }
        break;
    case Stage_LooseS2:
        if(Command_Code_ClampOpen != piCmdDone->m_nCmdID)
            return ERR_NONE;
        ewayos::Log::inf("ForkliftApp","ClampOpen to loose small paper finish!");
        nRetCode = MoveBack();
        if(ERR_NONE==nRetCode){
            m_uCurStage = Stage_BackToFinish;
        }
        break;
    default:
        break;

    }

    return ERR_NONE;
}

eint ForkliftApp::MoveForward()
{
    eint nRetCode = 0;
    euint unCmdSN=0;
    edouble dX0=0,dX1=0;
    edouble dY0=0,dY1=0;
    edouble dRz0=0,dRz1=0;
    CLocalizationMsg iLocate;
    GetMsgData(&iLocate);

    nRetCode = BaseSetDriveMode(DriveMode_Drive, unCmdSN);
    if(ERR_NONE!=nRetCode)
    {
        ewayos::Log::err("ForkliftApp","SetDriveMode failed, %d",nRetCode);
        return nRetCode;
    }

    dX0 = iLocate.m_iCurrentPose.m_iPosition.m_dx;
    dY0 = iLocate.m_iCurrentPose.m_iPosition.m_dy;
    dRz0 = iLocate.m_iCurrentPose.m_iRotation.m_dRz;
    dRz1 = dRz0+EPI/6;
    dX1 = dX0+1.5*cos(dRz1);
    dY1 = dY0+1.5*sin(dRz1);

    std::vector<C2DPoseWithV> vTraj;
    vTraj.resize(7);
    for(euint n=0;n<7;n++)
    {
        vTraj[n].m_sPose.m_dx = dX0+(n+1)*(dX1-dX0)/7;
        vTraj[n].m_sPose.m_dy = dY0+(n+1)*(dY1-dY0)/7;
        vTraj[n].m_sPose.m_dRz = dRz0;
        vTraj[n].m_dVelocity = -1;
        vTraj[n].m_nDirction = -1;
    }

    nRetCode = Base2DTrajWithV(vTraj,unCmdSN);
    if(ERR_NONE!=nRetCode)
    {
        ewayos::Log::err("ForkliftApp","MoveForward failed, Code %d",nRetCode);
        return nRetCode;
    }
    return ERR_NONE;
}

eint ForkliftApp::MoveBack(ebool bTurnFlag)
{
    eint nRetCode = 0;
    euint unCmdSN=0;
    edouble dX0=0,dX1=0,dX2=0;
    edouble dY0=0,dY1=0,dY2=0;
    edouble dRz0=0,dRz1=0;
    CLocalizationMsg iLocate;
    edouble dStraightDist = 0.3;
    edouble dTurnDist = 0.9;
    if(!bTurnFlag)
        dStraightDist = 2;
    GetMsgData(&iLocate);
    nRetCode = BaseSetDriveMode(DriveMode_Reverse, unCmdSN);
    if(ERR_NONE!=nRetCode)
    {
        ewayos::Log::err("ForkliftApp","SetDriveMode failed, %d",nRetCode);
        return nRetCode;
    }

    dX0 = iLocate.m_iCurrentPose.m_iPosition.m_dx;
    dY0 = iLocate.m_iCurrentPose.m_iPosition.m_dy;
    dRz0 = iLocate.m_iCurrentPose.m_iRotation.m_dRz;
    dX1 = dX0-dStraightDist*cos(dRz0);
    dY1 = dY0-dStraightDist*sin(dRz0);
    dRz1 = dRz0-EPI/6;
    dX2 = dX1-dTurnDist*cos(dRz1);
    dY2 = dY1-dTurnDist*sin(dRz1);

    std::vector<C2DPoseWithV> vTraj;
    if(bTurnFlag)
    {
        vTraj.resize(14);
    }
    else
    {
        vTraj.resize(7);
    }
    for(euint n=0;n<7;n++)
    {
        vTraj[n].m_sPose.m_dx = dX0+(n+1)*(dX1-dX0)/7;
        vTraj[n].m_sPose.m_dy = dY0+(n+1)*(dY1-dY0)/7;
        vTraj[n].m_sPose.m_dRz = dRz0;
        vTraj[n].m_dVelocity = -1;
        vTraj[n].m_nDirction =  C2DPoseWithV::Direction_Backward;
    }
    if(bTurnFlag)
    {
        for(euint n=0;n<7;n++)
        {
            vTraj[n+7].m_sPose.m_dx = dX1+(n+1)*(dX2-dX1)/7;
            vTraj[n+7].m_sPose.m_dy = dY1+(n+1)*(dY2-dY1)/7;
            vTraj[n+7].m_sPose.m_dRz = dRz1;
            vTraj[n+7].m_dVelocity = -1;
            vTraj[n+7].m_nDirction =  C2DPoseWithV::Direction_Backward;
        }
    }

    nRetCode = Base2DTrajWithV(vTraj,unCmdSN);
    if(ERR_NONE!=nRetCode)
    {
        ewayos::Log::err("ForkliftApp","MoveBack failed, Code %d",nRetCode);
        return nRetCode;
    }
    return ERR_NONE;
}

eint ForkliftApp::ProcAuthChanged(edouble dTimeStamp, CAuthorityMessage* piAuthMsg)
{
    return ERR_NONE;
}


