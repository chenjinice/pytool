#include <EwayFunc/FuncSdkLib.h>
#include "ForkliftApp.h"

int main()
{
   ewayos::FunctionRun("127.0.0.1","FolkliftApp");
   return 0;
}
