#ifndef ForkliftApp_H
#define ForkliftApp_H

#include <EwayFunc/FuncInterface.h>

Declare_FunLibSymble

class ForkliftApp:public CFuncInterface
{
public:
    ForkliftApp();
    virtual ~ForkliftApp();
    virtual eint Initialize(std::vector<eint> &vFeatureList,ebool &bLimbAuthority,edouble &dTimeOut);
    virtual eint Destroy();
    virtual eint CheckMsgCode(eint nMsgCode);

    virtual void JobStart();
    virtual void JobFailed(eint nErrCode);

    virtual eint ProcChildNotify(EGUID* pChildID, CSetParamMsg* piMsg);
    virtual eint ProcChildFunQuit(edouble dTimeStamp,EGUID* pgFunID,eint nRetCode,std::string& iRetStr);
    virtual eint ProcFeatureStatus(edouble dTimeStamp, CFeatureMessage* piFeaStatus);
    virtual eint ProcMotCmdDone(edouble dTimeStamp, CCmdDoneMessage* piCmdDone);
    virtual eint ProcAuthChanged(edouble dTimeStamp, CAuthorityMessage* piAuthMsg);
    virtual eint ProcTimer(edouble dTimeStamp);
    virtual eint ProcPaperRollMsg(edouble dTimeStamp, CPaperRollMsg* piMsg);
    virtual eint ProcLocalizationMsg(edouble dTimeStamp, CLocalizationMsg* piMsg);
    DECLEAR_FIFMESSAGE_MAP
private:
    eint BeginToTake();
    //eint DoKTurn();
    eint MoveBack(ebool bTurnFlag=true);

    eint MoveForward();

    eint Navigation();
#define InitStatusMask_DrvMode 0x00000001
#define InitStatusMask_Lift    0x00000002
#define InitStatusMask_Clamp   0x00000004
#define InitStatusMask_Tilt    0x00000008
#define InitStatusMask_Roll    0x00000010
    euint32 m_unInitStatus;

    efloat m_fClampOpenParam;
    efloat m_fClampCloseParam;

    efloat m_fLiftHighParam;
    efloat m_fLiftUpParam;
    efloat m_fLitDownParam;
    efloat m_fLitPileParam;

    efloat m_fWheelSpeed;
    eint m_nWaitCount;
    euint m_uCurStage;
    EGUID m_gVisualServoID;
    const echar* m_szVisualServoFuncName="ApproachAndGrasp";
    EGUID m_gNavigationID;
    const echar* m_szNavigationFuncName="Navigation";
};

#endif // ForkliftApp_H
