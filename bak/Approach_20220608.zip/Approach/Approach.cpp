#include "Approach.h"
#include <EwayFunc/FuncSdkLib.h>
#include <EwayMath/BasicMath.h>
#include <opencv2/imgproc/types_c.h>
#include <opencv2/imgproc.hpp>
#include <EwayMath/CoordinateConversion.h>
#include "TestUi.h"
#include "PosTransform.h"


Declare_FunSdk_Lib(Approach)
Declare_Function_ID("6e47a7c7-be00-4121-aad4-97eaac88b5d0")
Declare_Function_Priority(FunPri_Normal)

RegisterMessage_Start
RegisterMessage_End

BEGIN_FIFEMSG_MAP(Approach,CFuncInterface)
//MSG_FIFMAP(FunMsg_User+1,OnMessageProcess)
END_FIFMSG_MAP


using namespace std;
using namespace ewayos;
using namespace Eigen;


static const echar *        ClassName           = "Approach";


Approach::Approach()
{
    m_sParam.dWheelDistance             = 1.05;
    m_sParam.dWheelL                    = 1.75;
    m_sParam.dWheelCircle               = 2.136;
    m_sParam.dWheelRadius               = m_sParam.dWheelCircle/(2*EPI);
    m_sParam.dShortArmTipX              = 1.3056;
    m_sParam.dShortArmTipY              = 0.77676;
    m_sParam.dLongArmJointX             = 0.69859;
    m_sParam.dLongArmJointY             = -0.252;
    m_sParam.dLongArmLength             = 1.0674;
    m_sParam.dMaxWheelAngle             = 35.0/180.0*EPI;

    m_sParam.dPaperRadiusOffset         = 0.03;
    m_sParam.dPaperValidTime            = 0.3;
    m_sParam.dPaperAllowedDistance      = 1.0;
    m_sParam.dPaperMinRelativeX         = 2.0;
    m_sParam.dRobotPosValidTime         = 0.3;
    m_sParam.dWheelAngleValidTime       = 0.3;
    m_sParam.dWheelAngleAllowedDiff     = 3.0/180.0*EPI;
    m_sParam.dDistanceToSlow            = 2.5;
    m_sParam.dDistanceToStop            = 0.03;
    m_sParam.dMaxSpeed                  = 0.5;
    m_sParam.dMinSpeed                  = 0.05;

    m_sParam.dStep1WheelAngle           = 15.0/180.0*EPI;
    m_sParam.dStep1Yn                   = 0;

    MatrixTest();
}

Approach::~Approach()
{
}

eint Approach::Initialize(std::vector<eint> &vFeatureList,ebool &bLimbAuthority,edouble &dTimeOut)
{
    vFeatureList.clear();
//    vFeatureList.push_back(Message_Code_PaperRollDect);
    vFeatureList.push_back(Message_Code_Slam_Localization);
    vFeatureList.push_back(Message_Code_WheelState);
//    vFeatureList.push_back(Message_Code_CalibData);

    bLimbAuthority          = true;
    dTimeOut                = 3;

    this->TestMatrix();
    if( (false == this->GetXnYn()) || (false == this->GetStep1Xn()) )
    {
        FunQuit(INIT_FAILED);
        return INIT_FAILED;
    }else {
        Log::inf(ClassName,"Xn=%.2f,Yn=%.2f,step1Xn=%.2f,step1Yn=%.2f",m_dXn,m_dYn,m_dStep1Xn,m_dStep1Yn);
        return ERR_NONE;
    }
}

eint Approach::Destroy()
{
    return ERR_NONE;
}

eint Approach::CheckMsgCode(eint nMsgCode)
{
    UNUSED(nMsgCode);
    return MsgProcCode_Record;
}

void Approach::JobStart()
{
    SetTimer(100);
    return ;
}

void Approach::JobFailed(eint nErrCode)
{
    UNUSED(nErrCode);
    return ;
}

eint Approach::ProcTimer(edouble dTimeStamp)
{
    UNUSED(dTimeStamp);
    if (false == m_bMotionReady)
    {
        // 挂档
        eint    nErrorCode  = 0;
        euint   unCmdSN     = 0;
        eint    mode        = CSetModeCmd::DriveMode_Drive;
        nErrorCode          = BaseSetDriveMode(mode,unCmdSN);
        if(ERR_NONE == nErrorCode)
        {
            m_bMotionReady  = true;
        }
    }

    if(false == m_bStep1Finished)
    {
        this->ApproachStep1();
    }else {
        this->ApproachStep2();
    }
//    this->ApproachStep2();
//    this->TestLidar();

    return ERR_NONE;
}

// 计算叉子抓取纸卷直径时，圆心的坐标
ebool Approach::GetXnYn()
{
    edouble dR1 = m_dCatchPaperRadius * 2;
    edouble dD  = sqrt(pow(m_sParam.dShortArmTipX - m_sParam.dLongArmJointX, 2) + pow(m_sParam.dShortArmTipY - m_sParam.dLongArmJointY, 2));
    if(dD == 0)
    {
        Log::err(ClassName,"GetXnYn ,dD = 0");
        return false;
    }
    edouble dA  = dD/2.0 + (pow(dR1, 2) - pow(m_sParam.dLongArmLength, 2))/(2.0 * dD);
    if(fabs(dR1) < fabs(dA) )
    {
        Log::err(ClassName,"GetXnYn ,dR1(%f) < dA(%f)",dR1,dA);
        return false;
    }
    edouble dH = sqrt(pow(dR1, 2) - pow(dA, 2));
    m_dXn       = m_sParam.dShortArmTipX + dA/(2 * dD) * (m_sParam.dLongArmJointX - m_sParam.dShortArmTipX) + dH/(2 * dD) * (m_sParam.dShortArmTipY - m_sParam.dLongArmJointY);
    m_dYn       = m_sParam.dShortArmTipY + dA/(2 * dD) * (m_sParam.dLongArmJointY - m_sParam.dShortArmTipY) - dH/(2 * dD) * (m_sParam.dShortArmTipX - m_sParam.dLongArmJointX);
    return true;
}

// 算出步骤1的Xn
ebool Approach::GetStep1Xn()
{
    edouble dTheta  = m_sParam.dStep1WheelAngle;
    m_dStep1Yn      = m_sParam.dStep1Yn;
    if(dTheta == 0){
        Log::err(ClassName,"GetStep1Xn , WheelAngle = 0");
        return false;
    }
    if(dTheta > m_sParam.dMaxWheelAngle){
        Log::err(ClassName,"GetStep1Xn , WheelAngle(%.2f) > %.2f",dTheta,m_sParam.dMaxWheelAngle);
        return false;
    }
    edouble dTmp1   = 2*(m_dYn-m_dStep1Yn)*m_sParam.dWheelL/tan(m_sParam.dStep1WheelAngle);
    edouble dTmp2   = pow(m_dXn, 2) + pow(m_dYn, 2) - pow(m_dStep1Yn, 2);

    if( (dTmp1+dTmp2) < 0 ){
        Log::err(ClassName,"GetStep1Xn , can not reach");
        return false;
    }
    m_dStep1Xn        = sqrt(dTmp1+dTmp2);
    return true;
}

// 获取机器人位置数据
ebool Approach::GetRobotData()
{
    ebool               bResult         = false;
    edouble             dTime           = 0;
    CLocalizationMsg    iLocalization;
    if(false == GetMsgData(&iLocalization))
    {
        Log::err(ClassName,"get vps location failed");
    }else {
        m_sRobot.dTime                  = iLocalization.m_dTimeStamp;
        m_sRobot.dX                     = iLocalization.m_iCurrentPose.m_iPosition.m_dx;
        m_sRobot.dY                     = iLocalization.m_iCurrentPose.m_iPosition.m_dy;
        m_sRobot.dRz                    = iLocalization.m_iCurrentPose.m_iRotation.m_dRz;
        dTime                           = Time::GetCurrentTime() - m_sRobot.dTime;
        if(fabs(dTime) < m_sParam.dRobotPosValidTime)
        {
            Log::inf(ClassName,"robot pos,x=%.2f,y=%.2f,yaw=%.2f,dt=%.2f",m_sRobot.dX,m_sRobot.dY,m_sRobot.dRz,dTime);
            bResult                     = true;
        }else {
            Log::err(ClassName,"vps location too old, dt = %.2f",dTime);
        }
    }

    return bResult;
}

// 获取后轮角度数据
ebool Approach::GetWheelData()
{
    ebool               bResult         = false;
    edouble             dTime           = 0;
    CJointStateMsg      iWheelState;
    if(false == GetWheelStateMsg(&iWheelState))
    {
        Log::err(ClassName,"get wheel state failed");
    }else{
        m_sWheel.dTime                  = iWheelState.m_dTimeStamp;
        m_sWheel.dAngle                 = iWheelState.m_viJointList[2].m_dPosition;
        dTime                           = Time::GetCurrentTime() - m_sWheel.dTime;
        if(fabs(dTime) < m_sParam.dWheelAngleValidTime)
        {
            bResult                     = true;
        }else {
            Log::err(ClassName,"wheel state too old,dt=%.2f",dTime);
        }
    }
    return bResult;
}

// 获取雷达中纸卷数据
ebool Approach::GetPaperData(edouble &dPaperX, edouble &dPaperY)
{
    ebool                   bResult     = false;
    CPaperRollMsg           iMsg;
    vector<PaperData>       vPapers;
    RobotData               sRobot      = m_sRobot;
    edouble                 dNow        = Time::GetCurrentTime();
    edouble                 dTime       = 0;
    eint                    nCount      = 0;
    if (false == GetMsgData(&iMsg))
    {
        Log::inf(ClassName,"get paper roll failed");
        return bResult;
    }
    nCount                              = iMsg.m_vPaperRollList.size();
    dTime                               = dNow - iMsg.m_dTimeStamp;
    for(int i=0;i<nCount;i++)
    {
        const CPaperRoll   &iPaperRoll  = iMsg.m_vPaperRollList[i];
        PaperData           sPaper;
        sPaper.bValid     = true;
        sPaper.dTime      = iMsg.m_dTimeStamp;
        sPaper.dRadius    = iPaperRoll.m_fDiameter;
        sPaper.dX         = iPaperRoll.m_iPose.m_iPosition.m_dx;
        sPaper.dY         = iPaperRoll.m_iPose.m_iPosition.m_dy;
        sPaper.dMapX      = sRobot.dX + sPaper.dX*cos(sRobot.dRz) - sPaper.dY*sin(sRobot.dRz);
        sPaper.dMapY      = sRobot.dY + sPaper.dX*sin(sRobot.dRz) + sPaper.dY*cos(sRobot.dRz);
        Log::inf(ClassName,"paper[%d]:x=%.2f,y=%.2f,mapX=%.2f,mapY=%.2f,radius=%.02f,dt=%.3f",
                 i,sPaper.dX,sPaper.dY,sPaper.dMapX,sPaper.dMapY,sPaper.dRadius,dTime);
        if(iPaperRoll.m_iPose.m_iPosition.m_dx < m_sParam.dPaperMinRelativeX) continue;
        if(fabs(iPaperRoll.m_fDiameter - m_dApproachPaperRadius) > m_sParam.dPaperRadiusOffset) continue;
        if(fabs(dTime) > m_sParam.dPaperValidTime) continue;
        vPapers.push_back(sPaper);
    }
    eint     nIndex         = -1;
    efloat   fDist          = 1e7;
    nCount                  = vPapers.size();
    if(false == m_sPaper.bValid)
    {
        for(int i=0;i<nCount;i++)
        {
            const PaperData &sRoll  = vPapers[i];
            efloat  fTmp            = sqrt(pow(sRoll.dX,2) + pow(sRoll.dY,2));
            if(fTmp < fDist)
            {
                fDist               = fTmp;
                nIndex              = i;
            }
        }
    }else{
        for(int i=0;i<nCount;i++)
        {
            const PaperData &sRoll  = vPapers[i];
            efloat  fTmp            = sqrt(pow(sRoll.dMapX-m_sPaper.dMapX,2) + pow(sRoll.dMapY-m_sPaper.dMapY,2));
            if( (fTmp < m_sParam.dPaperAllowedDistance) && (fTmp < fDist) )
            {
                nIndex              = i;
                fDist               = fTmp;
            }
        }
    }
    if( -1 != nIndex )
    {
        m_sPaper = vPapers[nIndex];
    }
    if(m_sPaper.bValid)
    {
        dTime               = dNow - m_sPaper.dTime;
        if(fabs(dTime) < m_sParam.dPaperValidTime)
        {
            edouble dDeltaX = m_sPaper.dMapX - sRobot.dX;
            edouble dDeltaY = m_sPaper.dMapY - sRobot.dY;
            dPaperX         = dDeltaX*cos(sRobot.dRz)  + dDeltaY*sin(sRobot.dRz);
            dPaperY         = -dDeltaX*sin(sRobot.dRz) + dDeltaY*cos(sRobot.dRz);
            Log::inf(ClassName,"paperFromMap:x=%.2f,y=%.2f,radius=%.02f,dt=%.2f",dPaperX,dPaperY,m_sPaper.dRadius,dTime);
        }else{
            dPaperX         = m_sPaper.dX;
            dPaperY         = m_sPaper.dY;
            Log::inf(ClassName,"paperFromLidar:x=%.2f,y=%.2f,radius=%.02f,dt=%.2f",dPaperX,dPaperY,m_sPaper.dRadius,dTime);
        }
        bResult             = true;
    }
    return bResult;
}

// 获取realis中的机器人和纸卷数据
ebool Approach::GetRealisData(edouble &dPaperX, edouble &dPaperY)
{
    /*
    ebool               bResult             = false;
    edouble             dNow                = 0;
    eint                nCount              = 0;
    CRigidBodyList      iRealisItems;
    ebool               bHasRealisPaper     = false;
    ebool               bHasRealisMark      = false;
    edouble             dTime               = 0;
    edouble             dArr[4][4]          = {{0.9999,-0.0130,0,1.4194},
                                               {0.0130,0.9990,0,0.0206},
                                               {0,0,1.0000,-1.9824},
                                               {0,0,0,1.0000}};
    CTransformationM    iM;
    CPose               iRobotInRealis,iPaperInRealis,iTagInRealis,iRobotInTag,iPaperInRobot;

    TestUi * pUi                            = TestUi::Ins();
    pUi->SavePaperRadius(m_dApproachPaperRadius);

    memcpy(iM.m_vdMat,dArr,sizeof (dArr));
    CCSysConv::TransformationMatrixToPose(iM,iRobotInTag);
    dNow                                    = Time::GetCurrentTime();
    // 获取纸卷和车的全局位置
    if(GetMsgData(&iRealisItems))
    {
        nCount                              = iRealisItems.m_vItemList.size();
        for(int i=0;i<nCount;i++)
        {
            echar * strName                 = iRealisItems.m_vItemList[i].m_szName;
            string  str                     = strName;
            CPose   iPos                    = iRealisItems.m_vItemList[i].m_iPose;
            dTime                           = dNow - iRealisItems.m_dTimeStamp;
            if(str == "Mark"){
                iTagInRealis                = iPos;
                bHasRealisMark              = true;
            }
            if(str == "Paper"){
                iPaperInRealis              = iPos;
                bHasRealisPaper             = true;
            }
//            Log::inf(ClassName,"[%d]name=%s,x=%.3f,y=%.3f,Rz=%.3f",i,strName,iPos.m_iPosition.m_dx,iPos.m_iPosition.m_dy,iPos.m_iRotation.m_dRz);
        }
    }else{
        Log::inf(ClassName,"get realis data failed");
    }
    if(bHasRealisMark){
        CCSysConv::CoordinateTransform2(iRobotInTag,iTagInRealis,iRobotInRealis);
        Log::inf(ClassName,"markInRealis:x=%.3f,y=%.3f,Rz=%.3f,robot:x=%.3f,y=%.3f,Rz=%.3f,dt=%.3f",
                 iTagInRealis.m_iPosition.m_dx,iTagInRealis.m_iPosition.m_dy,iTagInRealis.m_iRotation.m_dRz,
                 iRobotInRealis.m_iPosition.m_dx,iRobotInRealis.m_iPosition.m_dy,iRobotInRealis.m_iRotation.m_dRz,dTime);
        pUi->SaveRobotPose(iRobotInRealis);
    }
    if(bHasRealisMark && bHasRealisPaper){
        CCSysConv::CoordinateTransform(iPaperInRealis,iRobotInRealis,iPaperInRobot);
        Log::inf(ClassName,"paperInRealis:x=%.3f,y=%.3f,paperInRobot:x=%.3f,y=%.3f,dt=%.3f",
                 iPaperInRealis.m_iPosition.m_dx,iPaperInRealis.m_iPosition.m_dy,
                 iPaperInRobot.m_iPosition.m_dx,iPaperInRobot.m_iPosition.m_dy,dTime);
        pUi->SavePaperInRealis(iPaperInRealis);
        dPaperX = iPaperInRobot.m_iPosition.m_dx;
        dPaperY = iPaperInRobot.m_iPosition.m_dy;
        if(dTime < 0.2){
            bResult                         = true;
        }else{
            Log::err(ClassName,"realis data too old,%.3f",dTime);
        }
    }
    // ui显示
    pUi->Show();
    return bResult;
    */
}

// 仿真中模拟一个纸卷数据
ebool Approach::GetSimulateData(edouble &dPaperX, edouble &dPaperY)
{
    ebool       bResult             = false;
    edouble     dMapX               = 8;
    edouble     dMapY               = 6;
    edouble     dTime               = 0;
    CLocalizationMsg    iLocalization;
    if(false == GetMsgData(&iLocalization))
    {
        Log::err(ClassName,"get vps location failed");
    }else {
        m_sRobot.dTime                  = iLocalization.m_dTimeStamp;
        m_sRobot.dX                     = iLocalization.m_iCurrentPose.m_iPosition.m_dx;
        m_sRobot.dY                     = iLocalization.m_iCurrentPose.m_iPosition.m_dy;
        m_sRobot.dRz                    = iLocalization.m_iCurrentPose.m_iRotation.m_dRz;
        dTime                           = Time::GetCurrentTime() - m_sRobot.dTime;
        edouble dDeltaX                 = dMapX - m_sRobot.dX;
        edouble dDeltaY                 = dMapY - m_sRobot.dY;
        dPaperX                         = dDeltaX*cos(m_sRobot.dRz)  + dDeltaY*sin(m_sRobot.dRz);
        dPaperY                         = -dDeltaX*sin(m_sRobot.dRz) + dDeltaY*cos(m_sRobot.dRz);
        Log::inf(ClassName,"robot:x=%.2f,y=%.2f,dRz=%.2f,paper:x=%.2f,y=%.2f,dt=%.2f",
                 m_sRobot.dX,m_sRobot.dY,m_sRobot.dRz,dPaperX,dPaperY,dTime);
        bResult                         = true;
    }
    return bResult;
}

// 计算要发送的速度和轮子角度
eint Approach::CalculateSpeed(edouble dXn, edouble dYn, edouble dPaperX, edouble dPaperY, edouble &dSpeed, edouble &dWheelAngle, ebool &bStop)
{
    eint        nResult             = ERR_NONE;
    edouble     dLinearSpeed        = 0;
    edouble     dDistance           = sqrt(pow(dXn-dPaperX,2) + pow(dYn-dPaperY,2));
    bStop                           = false;
    dSpeed                          = 0;
    dWheelAngle                     = 0;
    if ((dDistance < m_sParam.dDistanceToStop) || (dXn >= dPaperX))
    {
        dLinearSpeed                = 0.0;
        bStop                       = true;
        Log::inf(ClassName,"Xn=%.2f,Yn=%.2f,paperX=%.2f,paperY=%.2f,dist=%.2f,speed=%.2f,angle=%.2f(%.2f)",
                 dXn,dYn,dPaperX,dPaperY,dDistance,dLinearSpeed,dWheelAngle,m_sWheel.dAngle);
        return nResult;
    }
    // 两点的中垂线与y轴的交点（转动圆心位置)，中垂线方程为y=kx+b,k=-(x1-x2)/(y1-y2),b=(x1-x2)(x1+x2)/(y1-y2)/2+(y1+y2)/2;
    edouble dB                      = (dXn-dPaperX)*(dXn+dPaperX)/(dYn-dPaperY)/2+(dYn+dPaperY)/2;
    dWheelAngle                     = -atan(m_sParam.dWheelL/dB);
    if(fabs(dWheelAngle) > m_sParam.dMaxWheelAngle)
    {
        Log::err(ClassName,"calculate wheel angel err,%.2f>%.2f(max)",dWheelAngle,m_sParam.dMaxWheelAngle);
        bStop                       = true;
        nResult                     = PLANNING_FAIL;
        return nResult;
    }
    if (dDistance < m_sParam.dDistanceToSlow)
    {
        dLinearSpeed                = MAX(m_sParam.dMinSpeed,m_sParam.dMaxSpeed*dDistance/m_sParam.dDistanceToSlow);
    }else{
        dLinearSpeed                = m_sParam.dMaxSpeed;
    }
    if(fabs(dWheelAngle-m_sWheel.dAngle) > m_sParam.dWheelAngleAllowedDiff)
    {
        dLinearSpeed                = 0;
    }

    // 限制速度
    efloat fTmp                     = 0.1;
    if(dLinearSpeed > fTmp  )dLinearSpeed = fTmp;
    if(dLinearSpeed < -fTmp )dLinearSpeed = -fTmp;

    dSpeed                          = dLinearSpeed/m_sParam.dWheelRadius;
    Log::inf(ClassName,"Xn=%.2f,Yn=%.2f,paperX=%.2f,paperY=%.2f,dist=%.2f,speed=%.2f,angle=%.2f(%.2f)",
             dXn,dYn,dPaperX,dPaperY,dDistance,dLinearSpeed,dWheelAngle,m_sWheel.dAngle);
    return nResult;
}

eint Approach::ApproachStep1()
{
    eint    nErr        = ERR_NONE;
    ebool   bStop       = false;
    euint   unCmdSN     = 0;
    edouble dPaperX     = 0;
    edouble dPaperY     = 0;
    edouble dSpeed      = 0;
    edouble dWheelAngle = 0;
//    ebool   bRet        = this->GetRobotData() && this->GetWheelData() && this->GetPaperData(dPaperX,dPaperY);
    ebool   bRet        = this->GetWheelData() && this->GetSimulateData(dPaperX,dPaperY);
    if(!bRet)
    {
        BaseSteerCtrl(dSpeed,dWheelAngle,unCmdSN);
        nErr            = LOCALIZATION_LOST;
        return nErr;
    }
    nErr                = this->CalculateSpeed(m_dStep1Xn,m_dStep1Yn,dPaperX,dPaperY,dSpeed,dWheelAngle,bStop);
    if(ERR_NONE != nErr)
    {
        ApproachEnd(nErr);
    }else if(bStop){
        m_bStep1Finished    = true;
        Log::inf(ClassName,"approach step1 finished");
        BaseSteerCtrl(dSpeed,dWheelAngle,unCmdSN);
    }else{
        BaseSteerCtrl(dSpeed,dWheelAngle,unCmdSN);
    }
    return nErr;
}

eint Approach::ApproachStep2()
{
    eint    nErr        = ERR_NONE;
    ebool   bStop       = false;
    euint   unCmdSN     = 0;
    edouble dPaperX     = 0;
    edouble dPaperY     = 0;
    edouble dSpeed      = 0;
    edouble dWheelAngle = 0;
//    ebool   bRet        = this->GetRobotData() && this->GetWheelData() && this->GetPaperData(dPaperX,dPaperY);
    ebool   bRet        = this->GetWheelData() && this->GetSimulateData(dPaperX,dPaperY);
    if(!bRet)
    {
        BaseSteerCtrl(dSpeed,dWheelAngle,unCmdSN);
        nErr            = LOCALIZATION_LOST;
        return nErr;
    }
    nErr                = this->CalculateSpeed(m_dXn,m_dYn,dPaperX,dPaperY,dSpeed,dWheelAngle,bStop);
    if(ERR_NONE != nErr)
    {
        ApproachEnd(nErr);
    }else if(bStop){
        ApproachEnd(nErr);
    }else{
        BaseSteerCtrl(dSpeed,dWheelAngle,unCmdSN);
    }
    return nErr;
}

eint Approach::ApproachEnd(eint nErr)
{
    euint unCmdSN                   = 0;
    std::string strParamStr;
    std::vector<CFunParamVal> vParamList;
    string str                      = to_string(nErr);
    Log::inf(ClassName,"approach finished,err=%d\n",nErr);
    BaseStop(1,unCmdSN);
    vParamList.resize(1);
    vParamList[0].m_strParamName    = "RetCode";
    vParamList[0].m_strParamValue   = str;
    SetParamStr(vParamList,strParamStr);
    SendNotifyToParent(strParamStr);
    FunQuit(nErr);
    return ERR_NONE;
}

void Approach::GetRobotPosInRealis(const Eigen::Matrix4d &iMatRobotInMarker,const CPose &iMarkerInRealis, CPose &iRobotInRealis)
{
    Translation3d   iTransMarkerInRealis(iMarkerInRealis.m_iPosition.m_dx,iMarkerInRealis.m_iPosition.m_dy,iMarkerInRealis.m_iPosition.m_dz);
    AngleAxisd      iRx(iMarkerInRealis.m_iRotation.m_dRx, Eigen::Vector3d::UnitX());
    AngleAxisd      iRy(iMarkerInRealis.m_iRotation.m_dRy, Eigen::Vector3d::UnitY());
    AngleAxisd      iRz(iMarkerInRealis.m_iRotation.m_dRz, Eigen::Vector3d::UnitZ());
    // marker坐标系到realis坐标系的变换矩阵，顺序z,y,x，矩阵不满足乘法交换律
    Affine3d        iAffMarkerInRealis  = iTransMarkerInRealis*iRz*iRy*iRx;
    // robot坐标系到maker坐标系的变换矩阵
    Affine3d        iAffRobotInMarker(iMatRobotInMarker);
    // robot坐标系到realis坐标系的变换矩阵
    Affine3d        iAffRobotInRealis   = iAffMarkerInRealis * iAffRobotInMarker;
    iRobotInRealis.m_iPosition.m_dx     = iAffRobotInRealis.translation().x();
    iRobotInRealis.m_iPosition.m_dy     = iAffRobotInRealis.translation().y();
    iRobotInRealis.m_iPosition.m_dz     = iAffRobotInRealis.translation().z();
    iRobotInRealis.m_iRotation          = iMarkerInRealis.m_iRotation;
}

void Approach::TestLidar()
{
    /*
    edouble             dNow                = 0;
    eint                nCount              = 0;
    CRigidBodyList      iRealisItems;
    CPaperRollMsg       iFittingMsg;
    ebool               bHasLidarData       = false;
    ebool               bHasRealisPaper     = false;
    ebool               bHasRealisMark      = false;
    CPose               iFittingResult;
    edouble             dTimeLidar          = 0;
    edouble             dTimeRealis         = 0;
    edouble             dArr[4][4]          = {{0.9999,-0.0130,0,1.4194},
                                               {0.0130,0.9990,0,0.0206},
                                               {0,0,1.0000,-1.9824},
                                               {0,0,0,1.0000}};
    CTransformationM    iM;
    CPose               iRobotInRealis,iPaperInRealis,iTagInRealis,iRobotInTag,iPaperInRobot,iFittingResultInRealis;

    TestUi * pUi                            = TestUi::Ins();
    pUi->SavePaperRadius(m_dApproachPaperRadius);

    memcpy(iM.m_vdMat,dArr,sizeof (dArr));
    CCSysConv::TransformationMatrixToPose(iM,iRobotInTag);
    // 获取雷达和摄像头中纸卷位置
    if(GetMsgData(&iFittingMsg))
    {
        dNow                                = Time::GetCurrentTime();
        nCount                              = iFittingMsg.m_vPaperRollList.size();
        for(int i=0;i<nCount;i++)
        {
            const CPaperRoll   &iPaperRoll  = iFittingMsg.m_vPaperRollList[i];
            dTimeLidar                      = dNow - iFittingMsg.m_dTimeStamp;
            if(fabs(iPaperRoll.m_fDiameter - m_dApproachPaperRadius) > m_sParam.dPaperRadiusOffset) continue;
            Log::inf(ClassName,"paperInLidar[%d]:radius=%.2f,x=%.2f,y=%.2f,dt=%.3f",
                     i,iPaperRoll.m_fDiameter,iPaperRoll.m_iPose.m_iPosition.m_dx,iPaperRoll.m_iPose.m_iPosition.m_dy,dTimeLidar);
            iFittingResult                  = iPaperRoll.m_iPose;
            bHasLidarData                   = true;
        }
    }else{
        Log::inf(ClassName,"get paper roll failed\n");
    }
    // 获取纸卷和车的全局位置
    if(GetMsgData(&iRealisItems))
    {
        nCount                              = iRealisItems.m_vItemList.size();
        for(int i=0;i<nCount;i++)
        {
            echar * strName                 = iRealisItems.m_vItemList[i].m_szName;
            string  str                     = strName;
            CPose   iPos                    = iRealisItems.m_vItemList[i].m_iPose;
            dTimeRealis                     = dNow - iRealisItems.m_dTimeStamp;
            if(str == "Mark"){
                iTagInRealis                = iPos;
                bHasRealisMark              = true;
            }
            if(str == "Paper"){
                iPaperInRealis              = iPos;
                bHasRealisPaper             = true;
            }
//            Log::inf(ClassName,"[%d]name=%s,x=%.3f,y=%.3f,Rz=%.3f",i,strName,iPos.m_iPosition.m_dx,iPos.m_iPosition.m_dy,iPos.m_iRotation.m_dRz);
        }
    }else{
        Log::inf(ClassName,"get realis data failed");
    }
    if(bHasRealisMark){
        CCSysConv::CoordinateTransform2(iRobotInTag,iTagInRealis,iRobotInRealis);
        Log::inf(ClassName,"markInRealis:x=%.3f,y=%.3f,Rz=%.3f,robot:x=%.3f,y=%.3f,Rz=%.3f,dt=%.3f",
                 iTagInRealis.m_iPosition.m_dx,iTagInRealis.m_iPosition.m_dy,iTagInRealis.m_iRotation.m_dRz,
                 iRobotInRealis.m_iPosition.m_dx,iRobotInRealis.m_iPosition.m_dy,iRobotInRealis.m_iRotation.m_dRz,dTimeRealis);
        pUi->SaveRobotPose(iRobotInRealis);
    }
    if(bHasRealisMark && bHasRealisPaper){
        CCSysConv::CoordinateTransform(iPaperInRealis,iRobotInRealis,iPaperInRobot);
        Log::inf(ClassName,"paperInRealis:x=%.3f,y=%.3f,paperInRobot:x=%.3f,y=%.3f,dt=%.3f",
                 iPaperInRealis.m_iPosition.m_dx,iPaperInRealis.m_iPosition.m_dy,
                 iPaperInRobot.m_iPosition.m_dx,iPaperInRobot.m_iPosition.m_dy,dTimeRealis);
        pUi->SavePaperInRealis(iPaperInRealis);

    }
    // 打印差值
    if(bHasRealisMark && bHasRealisPaper && bHasLidarData){
        edouble dX                          = iPaperInRobot.m_iPosition.m_dx - iFittingResult.m_iPosition.m_dx;
        edouble dY                          = iPaperInRobot.m_iPosition.m_dy - iFittingResult.m_iPosition.m_dy;
        edouble dT                          = dTimeLidar-dTimeRealis;
        echar strText[200];
        Log::inf(ClassName,"diff============dx=%.3f,dy=%.3f,dt=%.3f",dX,dY,dT);
        // 雷达中的纸卷位置转换到Realis坐标系下的位置,用于ui显示
        edouble dTheta                              = iRobotInRealis.m_iRotation.m_dRz;
        CPosition &iPos                             = iFittingResult.m_iPosition;
        iFittingResultInRealis.m_iPosition.m_dx     = iRobotInRealis.m_iPosition.m_dx + iPos.m_dx*cos(dTheta) - iPos.m_dy*sin(dTheta);
        iFittingResultInRealis.m_iPosition.m_dy     = iRobotInRealis.m_iPosition.m_dy + iPos.m_dx*sin(dTheta) + iPos.m_dy*cos(dTheta);
        sprintf(strText,"dx=%.3f,dy=%.3f,dt=%.3f",dX,dY,dT);
        pUi->SavePaperInLidar(iFittingResultInRealis);
        pUi->SaveText(strText);
    }
    // ui显示
    pUi->Show();
    */
}

void Approach::TestMatrix()
{
    CPose               iFittingResult;
    edouble             dArr[4][4]          = {{0.9999,-0.0130,0,1.4194},
                                               {0.0130,0.9990,0,0.0206},
                                               {0,0,1.0000,-1.9824},
                                               {0,0,0,1.0000}};

    Matrix4d    iMat;
    iMat <<     0.9999,-0.0130,0,1.4194,
                0.0130,0.9990,0,0.0206,
                0,0,1.0000,-1.9824,
                0,0,0,1.0000;


    CTransformationM    iM;
    CPose               iRobotInRealis,iPaperInRealis,iTagInRealis,iRobotInTag,iPaperInRobot,iFittingResultInRealis;

    memcpy(iM.m_vdMat,dArr,sizeof (dArr));
    CCSysConv::TransformationMatrixToPose(iM,iRobotInTag);

    iTagInRealis.m_iPosition.m_dx   = 0;
    iTagInRealis.m_iPosition.m_dy   = 0;
    iTagInRealis.m_iRotation.m_dRz  = -0.5;

    iPaperInRealis.m_iPosition.m_dx   = 10;
    iPaperInRealis.m_iPosition.m_dy   = 10;
    iPaperInRealis.m_iRotation.m_dRz  = -0.5;

//    printf("%.3f,%.3f,%.3f\n",iRobotInTag.m_iRotation.m_dRx,iRobotInTag.m_iRotation.m_dRy,iRobotInTag.m_iRotation.m_dRz);

    CCSysConv::CoordinateTransform2(iRobotInTag,iTagInRealis,iRobotInRealis);
    Log::inf(ClassName,"markInRealis :x=%.3f,y=%.3f,z=%.3f,dRz=%.3f",
             iTagInRealis.m_iPosition.m_dx,iTagInRealis.m_iPosition.m_dy,iTagInRealis.m_iPosition.m_dz,iTagInRealis.m_iRotation.m_dRz);
    Log::inf(ClassName,"robotInRealis:x=%.3f,y=%.3f,z=%.3f,dRz=%.3f",
             iRobotInRealis.m_iPosition.m_dx,iRobotInRealis.m_iPosition.m_dy,iRobotInRealis.m_iPosition.m_dz,iRobotInRealis.m_iRotation.m_dRz
             );

    this->GetRobotPosInRealis(iMat,iTagInRealis,iRobotInRealis);
    Log::inf(ClassName,"robotInRealis:x=%.3f,y=%.3f,z=%.3f,dRz=%.3f",
             iRobotInRealis.m_iPosition.m_dx,iRobotInRealis.m_iPosition.m_dy,iRobotInRealis.m_iPosition.m_dz,iRobotInRealis.m_iRotation.m_dRz
             );


    CCSysConv::CoordinateTransform(iPaperInRealis,iRobotInRealis,iPaperInRobot);
    Log::inf(ClassName,"paperInRealis:x=%.3f,y=%.3f,paperInRobot:x=%.3f,y=%.3f",
             iPaperInRealis.m_iPosition.m_dx,iPaperInRealis.m_iPosition.m_dy,
             iPaperInRobot.m_iPosition.m_dx,iPaperInRobot.m_iPosition.m_dy);

}

